package com.mentorondemand.mentorondemand.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.mentorondemand.mentorondemand.model.Trainings;

public interface TrainingsRepository extends JpaRepository<Trainings, Long>{

}
